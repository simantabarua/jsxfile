
        const B = () => {
          return (
            <div>B</div>
          )
        }

        export default B;